//
//  CustomCollectionViewCell.swift
//  CollectionTrial2
//
//  Created by N Mompi Devi on 24/01/18.
//  Copyright © 2018 N Mompi Devi. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var ImageV: UIImageView!
//    @IBOutlet weak var Label1: UILabel!
}
